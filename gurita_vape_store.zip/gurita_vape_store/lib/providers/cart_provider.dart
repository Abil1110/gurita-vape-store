import 'package:flutter/material.dart';
import '../models/order_model.dart';
import '../models/product_model.dart';

class CartProvider extends ChangeNotifier {
  final List<CartItemModel> _items = [];

  List<CartItemModel> get items => List.unmodifiable(_items);
  int get itemCount => _items.length;
  int get totalQuantity => _items.fold(0, (sum, i) => sum + i.quantity);

  double get subtotal => _items.fold(0, (sum, i) => sum + i.subtotal);

  double get shippingCost {
    if (subtotal == 0) return 0;
    if (subtotal >= 500000) return 0; // Free shipping
    return 15000;
  }

  double get total => subtotal + shippingCost;

  bool get hasFreeShipping => subtotal >= 500000;

  void addItem(ProductModel product, {String? flavor, int qty = 1}) {
    final idx = _items.indexWhere(
      (i) => i.productId == product.id && i.selectedFlavor == flavor,
    );
    if (idx >= 0) {
      _items[idx].quantity += qty;
    } else {
      _items.add(CartItemModel.fromProduct(product, flavor: flavor)
        ..quantity = qty);
    }
    notifyListeners();
  }

  void removeItem(String productId, {String? flavor}) {
    _items.removeWhere(
      (i) => i.productId == productId && i.selectedFlavor == flavor,
    );
    notifyListeners();
  }

  void updateQuantity(String productId, int qty, {String? flavor}) {
    final idx = _items.indexWhere(
      (i) => i.productId == productId && i.selectedFlavor == flavor,
    );
    if (idx >= 0) {
      if (qty <= 0) {
        _items.removeAt(idx);
      } else {
        _items[idx].quantity = qty;
      }
      notifyListeners();
    }
  }

  void clearCart() {
    _items.clear();
    notifyListeners();
  }

  bool isInCart(String productId) {
    return _items.any((i) => i.productId == productId);
  }

  int getQuantity(String productId) {
    final item = _items.firstWhere(
      (i) => i.productId == productId,
      orElse: () => CartItemModel(
        productId: '', name: '', price: 0, imageUrl: ''),
    );
    return item.productId.isNotEmpty ? item.quantity : 0;
  }
}
