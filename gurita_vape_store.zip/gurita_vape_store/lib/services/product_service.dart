import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/product_model.dart';

class ProductService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  CollectionReference get _products => _firestore.collection('products');

  // Get all products
  Stream<List<ProductModel>> getProducts({String? category}) {
    Query query = _products.orderBy('createdAt', descending: true);
    if (category != null && category != 'Semua') {
      query = query.where('category', isEqualTo: category);
    }
    return query.snapshots().map((snap) => snap.docs
        .map((doc) => ProductModel.fromFirestore(
            doc.data() as Map<String, dynamic>, doc.id))
        .toList());
  }

  // Get featured products
  Stream<List<ProductModel>> getFeaturedProducts() {
    return _products
        .where('isFeatured', isEqualTo: true)
        .limit(6)
        .snapshots()
        .map((snap) => snap.docs
            .map((doc) => ProductModel.fromFirestore(
                doc.data() as Map<String, dynamic>, doc.id))
            .toList());
  }

  // Get new arrivals
  Stream<List<ProductModel>> getNewArrivals() {
    return _products
        .where('isNew', isEqualTo: true)
        .limit(8)
        .snapshots()
        .map((snap) => snap.docs
            .map((doc) => ProductModel.fromFirestore(
                doc.data() as Map<String, dynamic>, doc.id))
            .toList());
  }

  // Get product by ID
  Future<ProductModel?> getProductById(String id) async {
    final doc = await _products.doc(id).get();
    if (doc.exists) {
      return ProductModel.fromFirestore(
          doc.data() as Map<String, dynamic>, doc.id);
    }
    return null;
  }

  // Get wishlist products
  Future<List<ProductModel>> getWishlistProducts(List<String> ids) async {
    if (ids.isEmpty) return [];
    final snap = await _products.where(FieldPath.documentId, whereIn: ids).get();
    return snap.docs
        .map((doc) => ProductModel.fromFirestore(
            doc.data() as Map<String, dynamic>, doc.id))
        .toList();
  }

  // Search products
  Stream<List<ProductModel>> searchProducts(String query) {
    final q = query.toLowerCase();
    return _products.snapshots().map((snap) => snap.docs
        .map((doc) => ProductModel.fromFirestore(
            doc.data() as Map<String, dynamic>, doc.id))
        .where((p) =>
            p.name.toLowerCase().contains(q) ||
            p.brand.toLowerCase().contains(q) ||
            p.category.toLowerCase().contains(q))
        .toList());
  }

  // ── Admin CRUD ──────────────────────────────────────────────────────────────

  // Add product
  Future<void> addProduct(ProductModel product) async {
    await _products.add(product.toFirestore());
  }

  // Update product
  Future<void> updateProduct(String id, Map<String, dynamic> data) async {
    await _products.doc(id).update(data);
  }

  // Delete product
  Future<void> deleteProduct(String id) async {
    await _products.doc(id).delete();
  }

  // Update stock
  Future<void> updateStock(String id, int quantity) async {
    await _products.doc(id).update({
      'stock': FieldValue.increment(-quantity),
    });
  }
}
