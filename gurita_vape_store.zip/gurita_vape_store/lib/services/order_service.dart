import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/order_model.dart';

class OrderService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  CollectionReference get _orders => _firestore.collection('orders');

  // Create order
  Future<String> createOrder(OrderModel order) async {
    final doc = await _orders.add(order.toFirestore());
    return doc.id;
  }

  // Get user orders
  Stream<List<OrderModel>> getUserOrders(String userId) {
    return _orders
        .where('userId', isEqualTo: userId)
        .orderBy('createdAt', descending: true)
        .snapshots()
        .map((snap) => snap.docs
            .map((doc) => OrderModel.fromFirestore(
                doc.data() as Map<String, dynamic>, doc.id))
            .toList());
  }

  // Get all orders (Admin)
  Stream<List<OrderModel>> getAllOrders() {
    return _orders
        .orderBy('createdAt', descending: true)
        .snapshots()
        .map((snap) => snap.docs
            .map((doc) => OrderModel.fromFirestore(
                doc.data() as Map<String, dynamic>, doc.id))
            .toList());
  }

  // Update order status
  Future<void> updateOrderStatus(String orderId, OrderStatus status) async {
    await _orders.doc(orderId).update({
      'status': status.name,
      'updatedAt': DateTime.now(),
    });
  }

  // Cancel order
  Future<void> cancelOrder(String orderId) async {
    await _orders.doc(orderId).update({
      'status': OrderStatus.cancelled.name,
      'updatedAt': DateTime.now(),
    });
  }
}
