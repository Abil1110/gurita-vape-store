import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../providers/auth_provider.dart';
import '../../services/product_service.dart';
import '../../theme/app_theme.dart';
import '../../widgets/common_widgets.dart';
import '../auth/login_screen.dart';
import '../product/product_detail_screen.dart';

class WishlistScreen extends StatelessWidget {
  const WishlistScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthProvider>();

    if (!auth.isLoggedIn) {
      return Scaffold(
        appBar: const GvAppBar(title: 'Wishlist', showBack: false),
        body: GvEmptyState(
          icon: '❤️',
          title: 'Login untuk melihat wishlist',
          subtitle: 'Simpan produk favoritmu di sini',
          action: ElevatedButton(
            onPressed: () =>
                Navigator.pushNamed(context, LoginScreen.routeName),
            child: const Text('Masuk'),
          ),
        ),
      );
    }

    if (auth.user!.wishlist.isEmpty) {
      return const Scaffold(
        appBar: GvAppBar(title: 'Wishlist', showBack: false),
        body: GvEmptyState(
          icon: '❤️',
          title: 'Wishlist kosong',
          subtitle: 'Tap ikon hati pada produk yang kamu suka',
        ),
      );
    }

    return Scaffold(
      appBar: const GvAppBar(title: 'Wishlist', showBack: false),
      body: FutureBuilder(
        future: ProductService().getWishlistProducts(auth.user!.wishlist),
        builder: (context, snap) {
          if (!snap.hasData) return const GvLoading();
          final products = snap.data!;
          return GridView.builder(
            padding: const EdgeInsets.all(16),
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2,
              childAspectRatio: 0.65,
              crossAxisSpacing: 12,
              mainAxisSpacing: 12,
            ),
            itemCount: products.length,
            itemBuilder: (_, i) => ProductCard(
              product: products[i],
              onTap: () => Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (_) =>
                        ProductDetailScreen(product: products[i])),
              ),
            ),
          );
        },
      ),
    );
  }
}
