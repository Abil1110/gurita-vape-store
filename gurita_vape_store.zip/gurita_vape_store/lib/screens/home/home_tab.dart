import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../providers/auth_provider.dart';
import '../../services/product_service.dart';
import '../../theme/app_theme.dart';
import '../../widgets/common_widgets.dart';
import '../product/product_detail_screen.dart';
import '../product/catalog_screen.dart';
import '../admin/admin_screen.dart';
import '../../models/product_model.dart';

class HomeTab extends StatelessWidget {
  const HomeTab({super.key});

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthProvider>();
    final productService = ProductService();

    return Scaffold(
      body: CustomScrollView(
        slivers: [
          // App Bar
          SliverAppBar(
            floating: true,
            backgroundColor: AppColors.background,
            title: Row(
              children: [
                const Icon(Icons.smoking_rooms, color: AppColors.primary, size: 22),
                const SizedBox(width: 8),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('GURITA',
                        style: TextStyle(
                          color: AppColors.primary,
                          fontWeight: FontWeight.w800,
                          fontSize: 14,
                          letterSpacing: 2,
                        )),
                    const Text('VAPE STORE',
                        style: TextStyle(
                          color: AppColors.textSecondary,
                          fontSize: 9,
                          letterSpacing: 2,
                        )),
                  ],
                ),
              ],
            ),
            actions: [
              if (auth.isAdmin)
                IconButton(
                  icon: const Icon(Icons.admin_panel_settings, color: AppColors.accent),
                  onPressed: () => Navigator.pushNamed(context, AdminScreen.routeName),
                  tooltip: 'Admin Panel',
                ),
              IconButton(
                icon: const Icon(Icons.search, color: AppColors.textPrimary),
                onPressed: () => Navigator.pushNamed(context, CatalogScreen.routeName),
              ),
              IconButton(
                icon: auth.user?.photoUrl.isNotEmpty == true
                    ? CircleAvatar(
                        radius: 14,
                        backgroundImage: NetworkImage(auth.user!.photoUrl),
                      )
                    : const CircleAvatar(
                        radius: 14,
                        backgroundColor: AppColors.surface,
                        child: Icon(Icons.person, size: 16, color: AppColors.textSecondary),
                      ),
                onPressed: () => _showProfileSheet(context, auth),
              ),
              const SizedBox(width: 4),
            ],
            bottom: PreferredSize(
              preferredSize: const Size.fromHeight(1),
              child: Container(height: 1, color: AppColors.divider),
            ),
          ),

          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Greeting
                  Text(
                    'Halo, ${auth.user?.name.split(' ').first ?? 'Vapers'} 👋',
                    style: Theme.of(context).textTheme.titleLarge,
                  ),
                  const SizedBox(height: 4),
                  const Text('Temukan produk vape favoritmu',
                      style: TextStyle(color: AppColors.textSecondary)),
                  const SizedBox(height: 20),

                  // Banner
                  _Banner(),
                  const SizedBox(height: 24),

                  // Categories
                  const SectionHeader(title: 'Kategori'),
                  const SizedBox(height: 12),
                  _CategoryRow(),
                  const SizedBox(height: 24),

                  // Featured Products
                  SectionHeader(
                    title: 'Produk Unggulan',
                    actionLabel: 'Lihat Semua',
                    onAction: () =>
                        Navigator.pushNamed(context, CatalogScreen.routeName),
                  ),
                  const SizedBox(height: 12),
                ],
              ),
            ),
          ),

          // Featured Products Grid
          StreamBuilder<List<ProductModel>>(
            stream: productService.getFeaturedProducts(),
            builder: (context, snap) {
              if (!snap.hasData) {
                return const SliverToBoxAdapter(child: GvLoading());
              }
              final products = snap.data!;
              return SliverPadding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                sliver: SliverGrid(
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 2,
                    childAspectRatio: 0.65,
                    crossAxisSpacing: 12,
                    mainAxisSpacing: 12,
                  ),
                  delegate: SliverChildBuilderDelegate(
                    (ctx, i) => ProductCard(
                      product: products[i],
                      onTap: () => Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) =>
                              ProductDetailScreen(product: products[i]),
                        ),
                      ),
                    ),
                    childCount: products.length,
                  ),
                ),
              );
            },
          ),

          // New Arrivals
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(16, 24, 16, 12),
              child: SectionHeader(
                title: 'Baru Masuk 🔥',
                actionLabel: 'Lihat Semua',
                onAction: () =>
                    Navigator.pushNamed(context, CatalogScreen.routeName),
              ),
            ),
          ),
          StreamBuilder<List<ProductModel>>(
            stream: productService.getNewArrivals(),
            builder: (context, snap) {
              if (!snap.hasData) return const SliverToBoxAdapter(child: SizedBox());
              final products = snap.data!;
              return SliverToBoxAdapter(
                child: SizedBox(
                  height: 260,
                  child: ListView.separated(
                    scrollDirection: Axis.horizontal,
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    itemCount: products.length,
                    separatorBuilder: (_, __) => const SizedBox(width: 12),
                    itemBuilder: (ctx, i) => SizedBox(
                      width: 170,
                      child: ProductCard(
                        product: products[i],
                        onTap: () => Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) =>
                                ProductDetailScreen(product: products[i]),
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              );
            },
          ),

          const SliverToBoxAdapter(child: SizedBox(height: 32)),
        ],
      ),
    );
  }

  void _showProfileSheet(BuildContext context, AuthProvider auth) {
    showModalBottomSheet(
      context: context,
      backgroundColor: AppColors.surface,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (_) => Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 40, height: 4,
              decoration: BoxDecoration(
                color: AppColors.divider,
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            const SizedBox(height: 16),
            Text(auth.user?.name ?? 'Pengguna',
                style: Theme.of(context).textTheme.titleLarge),
            Text(auth.user?.email ?? '',
                style: const TextStyle(color: AppColors.textSecondary)),
            const SizedBox(height: 24),
            ListTile(
              leading: const Icon(Icons.person_outline, color: AppColors.textSecondary),
              title: const Text('Edit Profil'),
              onTap: () => Navigator.pop(context),
            ),
            const Divider(),
            ListTile(
              leading: const Icon(Icons.logout, color: AppColors.error),
              title: const Text('Keluar', style: TextStyle(color: AppColors.error)),
              onTap: () {
                Navigator.pop(context);
                auth.logout();
              },
            ),
          ],
        ),
      ),
    );
  }
}

// ─── Banner ───────────────────────────────────────────────────────────────────
class _Banner extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      height: 160,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        gradient: const LinearGradient(
          colors: [Color(0xFF00394D), Color(0xFF001A24)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        border: Border.all(color: AppColors.primary.withOpacity(0.3)),
      ),
      child: Stack(
        children: [
          // Decorative circles
          Positioned(
            right: -20,
            bottom: -20,
            child: Container(
              width: 120,
              height: 120,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: AppColors.primary.withOpacity(0.08),
              ),
            ),
          ),
          Positioned(
            right: 20,
            top: -30,
            child: Container(
              width: 80,
              height: 80,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: AppColors.primary.withOpacity(0.05),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                  decoration: BoxDecoration(
                    color: AppColors.accent,
                    borderRadius: BorderRadius.circular(6),
                  ),
                  child: const Text('PROMO HARI INI',
                      style: TextStyle(
                          color: Colors.white,
                          fontSize: 10,
                          fontWeight: FontWeight.w700)),
                ),
                const SizedBox(height: 8),
                const Text('Gratis Ongkir\nMinimum 500rb!',
                    style: TextStyle(
                      color: AppColors.textPrimary,
                      fontSize: 22,
                      fontWeight: FontWeight.w800,
                      height: 1.2,
                    )),
                const SizedBox(height: 12),
                const Text('Berlaku untuk semua produk',
                    style: TextStyle(
                        color: AppColors.textSecondary, fontSize: 12)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// ─── Category Row ─────────────────────────────────────────────────────────────
class _CategoryRow extends StatelessWidget {
  final categories = [
    {'icon': '💨', 'label': 'Pod'},
    {'icon': '🔧', 'label': 'Mod'},
    {'icon': '🧪', 'label': 'Liquid'},
    {'icon': '🌀', 'label': 'Coil'},
    {'icon': '🎒', 'label': 'Aksesori'},
  ];

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: categories
          .map(
            (c) => GestureDetector(
              onTap: () => Navigator.pushNamed(
                context,
                CatalogScreen.routeName,
                arguments: c['label'],
              ),
              child: Column(
                children: [
                  Container(
                    width: 56,
                    height: 56,
                    decoration: BoxDecoration(
                      color: AppColors.card,
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(color: AppColors.divider),
                    ),
                    child: Center(
                      child: Text(c['icon']!,
                          style: const TextStyle(fontSize: 24)),
                    ),
                  ),
                  const SizedBox(height: 6),
                  Text(c['label']!,
                      style: const TextStyle(
                          color: AppColors.textSecondary,
                          fontSize: 11)),
                ],
              ),
            ),
          )
          .toList(),
    );
  }
}
