import 'package:flutter/material.dart';
import 'package:uuid/uuid.dart';
import '../../models/product_model.dart';
import '../../services/product_service.dart';
import '../../theme/app_theme.dart';
import '../../widgets/common_widgets.dart';

class AdminProductForm extends StatefulWidget {
  final ProductModel? product;
  const AdminProductForm({super.key, this.product});

  @override
  State<AdminProductForm> createState() => _AdminProductFormState();
}

class _AdminProductFormState extends State<AdminProductForm> {
  final _formKey = GlobalKey<FormState>();
  final _service = ProductService();
  bool _isLoading = false;

  late final _nameCtrl = TextEditingController(text: widget.product?.name);
  late final _descCtrl =
      TextEditingController(text: widget.product?.description);
  late final _priceCtrl = TextEditingController(
      text: widget.product?.price.toStringAsFixed(0));
  late final _origPriceCtrl = TextEditingController(
      text: widget.product?.originalPrice?.toStringAsFixed(0));
  late final _brandCtrl = TextEditingController(text: widget.product?.brand);
  late final _imageCtrl =
      TextEditingController(text: widget.product?.imageUrl);
  late final _stockCtrl =
      TextEditingController(text: widget.product?.stock.toString());
  late final _flavorsCtrl = TextEditingController(
      text: widget.product?.flavors.join(', '));

  late String _category =
      widget.product?.category ?? ProductCategory.pod;
  late bool _isNew = widget.product?.isNew ?? false;
  late bool _isFeatured = widget.product?.isFeatured ?? false;

  bool get _isEditing => widget.product != null;

  @override
  void dispose() {
    _nameCtrl.dispose();
    _descCtrl.dispose();
    _priceCtrl.dispose();
    _origPriceCtrl.dispose();
    _brandCtrl.dispose();
    _imageCtrl.dispose();
    _stockCtrl.dispose();
    _flavorsCtrl.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() => _isLoading = true);

    try {
      final flavors = _flavorsCtrl.text
          .split(',')
          .map((f) => f.trim())
          .where((f) => f.isNotEmpty)
          .toList();

      final product = ProductModel(
        id: widget.product?.id ?? const Uuid().v4(),
        name: _nameCtrl.text.trim(),
        description: _descCtrl.text.trim(),
        price: double.parse(_priceCtrl.text.replaceAll(',', '')),
        originalPrice: _origPriceCtrl.text.isEmpty
            ? null
            : double.parse(_origPriceCtrl.text.replaceAll(',', '')),
        imageUrl: _imageCtrl.text.trim(),
        category: _category,
        brand: _brandCtrl.text.trim(),
        stock: int.parse(_stockCtrl.text),
        flavors: flavors,
        isNew: _isNew,
        isFeatured: _isFeatured,
        createdAt: widget.product?.createdAt ?? DateTime.now(),
      );

      if (_isEditing) {
        await _service.updateProduct(product.id, product.toFirestore());
      } else {
        await _service.addProduct(product);
      }

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(_isEditing
                ? 'Produk berhasil diperbarui'
                : 'Produk berhasil ditambahkan'),
          ),
        );
        Navigator.pop(context);
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Gagal menyimpan: $e')),
        );
      }
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: GvAppBar(
          title: _isEditing ? 'Edit Produk' : 'Tambah Produk'),
      body: Form(
        key: _formKey,
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Column(
            children: [
              _buildField(_nameCtrl, 'Nama Produk'),
              const SizedBox(height: 12),
              _buildField(_brandCtrl, 'Brand'),
              const SizedBox(height: 12),
              // Category
              DropdownButtonFormField<String>(
                value: _category,
                decoration: const InputDecoration(labelText: 'Kategori'),
                dropdownColor: AppColors.surface,
                items: ProductCategory.all
                    .map((c) =>
                        DropdownMenuItem(value: c, child: Text(c)))
                    .toList(),
                onChanged: (v) => setState(() => _category = v!),
              ),
              const SizedBox(height: 12),
              _buildField(_priceCtrl, 'Harga',
                  keyboardType: TextInputType.number),
              const SizedBox(height: 12),
              _buildField(_origPriceCtrl, 'Harga Asli (opsional)',
                  keyboardType: TextInputType.number,
                  required: false),
              const SizedBox(height: 12),
              _buildField(_stockCtrl, 'Stok',
                  keyboardType: TextInputType.number),
              const SizedBox(height: 12),
              _buildField(_imageCtrl, 'URL Gambar'),
              const SizedBox(height: 12),
              _buildField(_flavorsCtrl, 'Rasa (pisahkan koma)',
                  required: false,
                  hint: 'Mango, Strawberry, Mint'),
              const SizedBox(height: 12),
              _buildField(_descCtrl, 'Deskripsi',
                  maxLines: 4),
              const SizedBox(height: 16),
              // Toggles
              SwitchListTile(
                value: _isNew,
                onChanged: (v) => setState(() => _isNew = v),
                title: const Text('Tandai sebagai Baru'),
                activeColor: AppColors.primary,
                contentPadding: EdgeInsets.zero,
              ),
              SwitchListTile(
                value: _isFeatured,
                onChanged: (v) => setState(() => _isFeatured = v),
                title: const Text('Tampilkan di Beranda (Featured)'),
                activeColor: AppColors.primary,
                contentPadding: EdgeInsets.zero,
              ),
              const SizedBox(height: 32),
              ElevatedButton(
                onPressed: _isLoading ? null : _save,
                style: ElevatedButton.styleFrom(
                    minimumSize: const Size(double.infinity, 50)),
                child: _isLoading
                    ? const CircularProgressIndicator(
                        color: Colors.black, strokeWidth: 2)
                    : Text(_isEditing ? 'Simpan Perubahan' : 'Tambah Produk'),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildField(
    TextEditingController ctrl,
    String label, {
    TextInputType keyboardType = TextInputType.text,
    int maxLines = 1,
    String? hint,
    bool required = true,
  }) {
    return TextFormField(
      controller: ctrl,
      keyboardType: keyboardType,
      maxLines: maxLines,
      decoration: InputDecoration(labelText: label, hintText: hint),
      validator: required
          ? (v) => v == null || v.isEmpty ? '$label wajib diisi' : null
          : null,
    );
  }
}
