import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../models/order_model.dart';
import '../../models/product_model.dart';
import '../../providers/auth_provider.dart';
import '../../services/order_service.dart';
import '../../services/product_service.dart';
import '../../theme/app_theme.dart';
import '../../utils/format_utils.dart';
import '../../widgets/common_widgets.dart';
import 'admin_product_form.dart';

class AdminScreen extends StatefulWidget {
  const AdminScreen({super.key});
  static const routeName = '/admin';

  @override
  State<AdminScreen> createState() => _AdminScreenState();
}

class _AdminScreenState extends State<AdminScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;
  final _productService = ProductService();
  final _orderService = OrderService();

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthProvider>();
    if (!auth.isAdmin) {
      return Scaffold(
        appBar: const GvAppBar(title: 'Admin'),
        body: const GvEmptyState(
          icon: '🚫',
          title: 'Akses Ditolak',
          subtitle: 'Halaman ini hanya untuk admin',
        ),
      );
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text('Admin Panel'),
        bottom: TabBar(
          controller: _tabController,
          indicatorColor: AppColors.primary,
          labelColor: AppColors.primary,
          unselectedLabelColor: AppColors.textSecondary,
          tabs: const [
            Tab(text: 'Produk', icon: Icon(Icons.inventory_2_outlined)),
            Tab(text: 'Pesanan', icon: Icon(Icons.receipt_long_outlined)),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tabController,
        children: [
          _ProductsTab(service: _productService),
          _OrdersTab(service: _orderService),
        ],
      ),
      floatingActionButton: ListenableBuilder(
        listenable: _tabController,
        builder: (_, __) {
          if (_tabController.index == 0) {
            return FloatingActionButton.extended(
              onPressed: () => Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (_) => const AdminProductForm()),
              ),
              backgroundColor: AppColors.primary,
              foregroundColor: Colors.black,
              icon: const Icon(Icons.add),
              label: const Text('Tambah Produk'),
            );
          }
          return const SizedBox();
        },
      ),
    );
  }
}

// ─── Products Tab ─────────────────────────────────────────────────────────────
class _ProductsTab extends StatelessWidget {
  final ProductService service;
  const _ProductsTab({required this.service});

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<List<ProductModel>>(
      stream: service.getProducts(),
      builder: (context, snap) {
        if (!snap.hasData) return const GvLoading();
        final products = snap.data!;
        if (products.isEmpty) {
          return const GvEmptyState(
            icon: '📦',
            title: 'Belum ada produk',
            subtitle: 'Tap + untuk menambah produk',
          );
        }
        return ListView.separated(
          padding: const EdgeInsets.all(16),
          itemCount: products.length,
          separatorBuilder: (_, __) => const SizedBox(height: 10),
          itemBuilder: (_, i) =>
              _AdminProductTile(product: products[i], service: service),
        );
      },
    );
  }
}

class _AdminProductTile extends StatelessWidget {
  final ProductModel product;
  final ProductService service;
  const _AdminProductTile({required this.product, required this.service});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppColors.card,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: AppColors.divider),
      ),
      child: Row(
        children: [
          // Image
          ClipRRect(
            borderRadius: BorderRadius.circular(8),
            child: product.imageUrl.isNotEmpty
                ? Image.network(product.imageUrl,
                    width: 56, height: 56, fit: BoxFit.cover)
                : Container(
                    width: 56,
                    height: 56,
                    color: AppColors.surface,
                    child: const Icon(Icons.image, color: AppColors.textSecondary),
                  ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(product.name,
                    style: const TextStyle(fontWeight: FontWeight.w600),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis),
                Text(product.category,
                    style: const TextStyle(
                        color: AppColors.textSecondary, fontSize: 12)),
                const SizedBox(height: 4),
                Row(
                  children: [
                    Text(FormatUtils.currency(product.price),
                        style: const TextStyle(
                            color: AppColors.primary,
                            fontWeight: FontWeight.w700,
                            fontSize: 13)),
                    const Spacer(),
                    Text('Stok: ${product.stock}',
                        style: TextStyle(
                            fontSize: 12,
                            color: product.isInStock
                                ? AppColors.success
                                : AppColors.error)),
                  ],
                ),
              ],
            ),
          ),
          // Actions
          PopupMenuButton<String>(
            color: AppColors.surface,
            icon: const Icon(Icons.more_vert, color: AppColors.textSecondary),
            onSelected: (action) async {
              if (action == 'edit') {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => AdminProductForm(product: product),
                  ),
                );
              } else if (action == 'delete') {
                final confirm = await showDialog<bool>(
                  context: context,
                  builder: (_) => AlertDialog(
                    backgroundColor: AppColors.surface,
                    title: const Text('Hapus Produk?'),
                    content: Text('Hapus "${product.name}"?',
                        style: const TextStyle(color: AppColors.textSecondary)),
                    actions: [
                      TextButton(
                          onPressed: () => Navigator.pop(context, false),
                          child: const Text('Batal')),
                      ElevatedButton(
                        style: ElevatedButton.styleFrom(
                            backgroundColor: AppColors.error),
                        onPressed: () => Navigator.pop(context, true),
                        child: const Text('Hapus',
                            style: TextStyle(color: Colors.white)),
                      ),
                    ],
                  ),
                );
                if (confirm == true) {
                  await service.deleteProduct(product.id);
                }
              }
            },
            itemBuilder: (_) => [
              const PopupMenuItem(value: 'edit', child: Text('Edit')),
              const PopupMenuItem(
                value: 'delete',
                child: Text('Hapus', style: TextStyle(color: AppColors.error)),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

// ─── Orders Tab ───────────────────────────────────────────────────────────────
class _OrdersTab extends StatelessWidget {
  final OrderService service;
  const _OrdersTab({required this.service});

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<List<OrderModel>>(
      stream: service.getAllOrders(),
      builder: (context, snap) {
        if (!snap.hasData) return const GvLoading();
        final orders = snap.data!;
        if (orders.isEmpty) {
          return const GvEmptyState(
            icon: '📋',
            title: 'Belum ada pesanan',
            subtitle: '',
          );
        }
        return ListView.separated(
          padding: const EdgeInsets.all(16),
          itemCount: orders.length,
          separatorBuilder: (_, __) => const SizedBox(height: 10),
          itemBuilder: (_, i) =>
              _AdminOrderTile(order: orders[i], service: service),
        );
      },
    );
  }
}

class _AdminOrderTile extends StatelessWidget {
  final OrderModel order;
  final OrderService service;
  const _AdminOrderTile({required this.order, required this.service});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppColors.card,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: AppColors.divider),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(FormatUtils.shortenId(order.id),
                  style: const TextStyle(fontWeight: FontWeight.w700)),
              Text(FormatUtils.date(order.createdAt),
                  style: const TextStyle(
                      color: AppColors.textSecondary, fontSize: 12)),
            ],
          ),
          const SizedBox(height: 4),
          Text(order.recipientName,
              style: const TextStyle(color: AppColors.textSecondary, fontSize: 13)),
          Text(FormatUtils.currency(order.total),
              style: const TextStyle(
                  color: AppColors.primary, fontWeight: FontWeight.w700)),
          const SizedBox(height: 10),
          // Status Dropdown
          DropdownButtonFormField<OrderStatus>(
            value: order.status,
            decoration: const InputDecoration(
              labelText: 'Status',
              contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            ),
            dropdownColor: AppColors.surface,
            items: OrderStatus.values.map((s) {
              return DropdownMenuItem(
                value: s,
                child: Text(order.copyWithStatus(s).statusLabel),
              );
            }).toList(),
            onChanged: (s) {
              if (s != null) service.updateOrderStatus(order.id, s);
            },
          ),
        ],
      ),
    );
  }
}

extension on OrderModel {
  OrderModel copyWithStatus(OrderStatus s) => OrderModel(
        id: id,
        userId: userId,
        items: items,
        subtotal: subtotal,
        shippingCost: shippingCost,
        total: total,
        shippingAddress: shippingAddress,
        recipientName: recipientName,
        recipientPhone: recipientPhone,
        paymentMethod: paymentMethod,
        status: s,
        createdAt: createdAt,
      );
}
