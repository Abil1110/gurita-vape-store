import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:cached_network_image/cached_network_image.dart';
import '../../providers/cart_provider.dart';
import '../../providers/auth_provider.dart';
import '../../theme/app_theme.dart';
import '../../utils/format_utils.dart';
import '../../widgets/common_widgets.dart';
import '../checkout/checkout_screen.dart';
import '../auth/login_screen.dart';

class CartScreen extends StatelessWidget {
  const CartScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthProvider>();
    final cart = context.watch<CartProvider>();

    if (!auth.isLoggedIn) {
      return Scaffold(
        appBar: const GvAppBar(title: 'Keranjang', showBack: false),
        body: GvEmptyState(
          icon: '🛒',
          title: 'Login untuk melihat keranjang',
          subtitle: 'Masuk ke akun kamu untuk mulai belanja',
          action: ElevatedButton(
            onPressed: () =>
                Navigator.pushNamed(context, LoginScreen.routeName),
            child: const Text('Masuk'),
          ),
        ),
      );
    }

    if (cart.items.isEmpty) {
      return Scaffold(
        appBar: const GvAppBar(title: 'Keranjang', showBack: false),
        body: GvEmptyState(
          icon: '🛒',
          title: 'Keranjang kosong',
          subtitle: 'Tambahkan produk ke keranjang kamu',
        ),
      );
    }

    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: false,
        title: Text('Keranjang (${cart.itemCount})'),
        actions: [
          TextButton(
            onPressed: () => _confirmClear(context, cart),
            child: const Text('Hapus Semua',
                style: TextStyle(color: AppColors.error, fontSize: 13)),
          ),
        ],
        bottom: const PreferredSize(
          preferredSize: Size.fromHeight(1),
          child: Divider(height: 1),
        ),
      ),
      body: Column(
        children: [
          Expanded(
            child: ListView.separated(
              padding: const EdgeInsets.all(16),
              itemCount: cart.items.length,
              separatorBuilder: (_, __) => const SizedBox(height: 12),
              itemBuilder: (_, i) => _CartItemTile(item: cart.items[i]),
            ),
          ),
          // Summary
          _CartSummary(cart: cart),
        ],
      ),
    );
  }

  void _confirmClear(BuildContext context, CartProvider cart) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: AppColors.surface,
        title: const Text('Hapus Semua?'),
        content: const Text('Semua item di keranjang akan dihapus.',
            style: TextStyle(color: AppColors.textSecondary)),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Batal'),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: AppColors.error),
            onPressed: () {
              cart.clearCart();
              Navigator.pop(context);
            },
            child: const Text('Hapus', style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
    );
  }
}

class _CartItemTile extends StatelessWidget {
  final item;
  const _CartItemTile({required this.item});

  @override
  Widget build(BuildContext context) {
    final cart = context.read<CartProvider>();
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: AppColors.card,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: AppColors.divider),
      ),
      child: Row(
        children: [
          // Image
          ClipRRect(
            borderRadius: BorderRadius.circular(10),
            child: CachedNetworkImage(
              imageUrl: item.imageUrl,
              width: 70,
              height: 70,
              fit: BoxFit.cover,
              errorWidget: (_, __, ___) => Container(
                width: 70, height: 70,
                color: AppColors.surface,
                child: const Icon(Icons.image, color: AppColors.textSecondary),
              ),
            ),
          ),
          const SizedBox(width: 12),
          // Info
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(item.name,
                    style: const TextStyle(
                        fontWeight: FontWeight.w600, fontSize: 14),
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis),
                if (item.selectedFlavor != null)
                  Text(item.selectedFlavor!,
                      style: const TextStyle(
                          color: AppColors.primary, fontSize: 12)),
                const SizedBox(height: 8),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(FormatUtils.currency(item.subtotal),
                        style: const TextStyle(
                            color: AppColors.primary,
                            fontWeight: FontWeight.w700)),
                    // Qty controls
                    Row(
                      children: [
                        _QtyBtn(
                          icon: Icons.remove,
                          onTap: () => cart.updateQuantity(
                              item.productId, item.quantity - 1,
                              flavor: item.selectedFlavor),
                        ),
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 12),
                          child: Text('${item.quantity}',
                              style: const TextStyle(
                                  fontWeight: FontWeight.w700)),
                        ),
                        _QtyBtn(
                          icon: Icons.add,
                          onTap: () => cart.updateQuantity(
                              item.productId, item.quantity + 1,
                              flavor: item.selectedFlavor),
                        ),
                      ],
                    ),
                  ],
                ),
              ],
            ),
          ),
          // Delete
          IconButton(
            icon: const Icon(Icons.delete_outline,
                color: AppColors.error, size: 20),
            onPressed: () => cart.removeItem(item.productId,
                flavor: item.selectedFlavor),
          ),
        ],
      ),
    );
  }
}

class _QtyBtn extends StatelessWidget {
  final IconData icon;
  final VoidCallback onTap;
  const _QtyBtn({required this.icon, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 28,
        height: 28,
        decoration: BoxDecoration(
          color: AppColors.surface,
          borderRadius: BorderRadius.circular(6),
          border: Border.all(color: AppColors.divider),
        ),
        child: Icon(icon, size: 14),
      ),
    );
  }
}

class _CartSummary extends StatelessWidget {
  final CartProvider cart;
  const _CartSummary({required this.cart});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.fromLTRB(20, 16, 20, 24),
      decoration: const BoxDecoration(
        color: AppColors.surface,
        border: Border(top: BorderSide(color: AppColors.divider)),
      ),
      child: Column(
        children: [
          _Row(label: 'Subtotal', value: FormatUtils.currency(cart.subtotal)),
          const SizedBox(height: 6),
          _Row(
            label: 'Ongkir',
            value: cart.hasFreeShipping
                ? 'GRATIS 🎉'
                : FormatUtils.currency(cart.shippingCost),
            valueColor:
                cart.hasFreeShipping ? AppColors.success : AppColors.textPrimary,
          ),
          if (!cart.hasFreeShipping)
            Padding(
              padding: const EdgeInsets.only(top: 4),
              child: Text(
                'Belanja ${FormatUtils.currency(500000 - cart.subtotal)} lagi untuk gratis ongkir!',
                style: const TextStyle(
                    color: AppColors.textSecondary, fontSize: 11),
              ),
            ),
          const SizedBox(height: 12),
          const Divider(),
          const SizedBox(height: 12),
          _Row(
            label: 'Total',
            value: FormatUtils.currency(cart.total),
            isTotal: true,
          ),
          const SizedBox(height: 16),
          ElevatedButton(
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const CheckoutScreen()),
            ),
            style: ElevatedButton.styleFrom(
                minimumSize: const Size(double.infinity, 50)),
            child: Text('Checkout (${cart.totalQuantity} item)'),
          ),
        ],
      ),
    );
  }
}

class _Row extends StatelessWidget {
  final String label;
  final String value;
  final Color? valueColor;
  final bool isTotal;
  const _Row({
    required this.label,
    required this.value,
    this.valueColor,
    this.isTotal = false,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(label,
            style: TextStyle(
                color:
                    isTotal ? AppColors.textPrimary : AppColors.textSecondary,
                fontWeight:
                    isTotal ? FontWeight.w700 : FontWeight.normal,
                fontSize: isTotal ? 16 : 14)),
        Text(value,
            style: TextStyle(
                color: valueColor ??
                    (isTotal ? AppColors.primary : AppColors.textPrimary),
                fontWeight: FontWeight.w700,
                fontSize: isTotal ? 18 : 14)),
      ],
    );
  }
}
