import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../models/order_model.dart';
import '../../providers/auth_provider.dart';
import '../../services/order_service.dart';
import '../../theme/app_theme.dart';
import '../../utils/format_utils.dart';
import '../../widgets/common_widgets.dart';
import '../auth/login_screen.dart';

class OrderHistoryScreen extends StatelessWidget {
  const OrderHistoryScreen({super.key});
  static const routeName = '/orders';

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthProvider>();

    if (!auth.isLoggedIn) {
      return Scaffold(
        appBar: const GvAppBar(title: 'Pesanan Saya', showBack: false),
        body: GvEmptyState(
          icon: '📋',
          title: 'Login untuk melihat pesanan',
          subtitle: 'Masuk ke akun kamu untuk melihat riwayat pesanan',
          action: ElevatedButton(
            onPressed: () =>
                Navigator.pushNamed(context, LoginScreen.routeName),
            child: const Text('Masuk'),
          ),
        ),
      );
    }

    return Scaffold(
      appBar: const GvAppBar(title: 'Pesanan Saya', showBack: false),
      body: StreamBuilder<List<OrderModel>>(
        stream: OrderService().getUserOrders(auth.user!.uid),
        builder: (context, snap) {
          if (!snap.hasData) return const GvLoading();
          final orders = snap.data!;
          if (orders.isEmpty) {
            return const GvEmptyState(
              icon: '📋',
              title: 'Belum ada pesanan',
              subtitle: 'Yuk mulai belanja di Gurita Vape Store!',
            );
          }
          return ListView.separated(
            padding: const EdgeInsets.all(16),
            itemCount: orders.length,
            separatorBuilder: (_, __) => const SizedBox(height: 12),
            itemBuilder: (_, i) => _OrderCard(order: orders[i]),
          );
        },
      ),
    );
  }
}

class _OrderCard extends StatelessWidget {
  final OrderModel order;
  const _OrderCard({required this.order});

  Color _statusColor(OrderStatus s) {
    switch (s) {
      case OrderStatus.pending:
        return AppColors.warning;
      case OrderStatus.processing:
        return AppColors.primary;
      case OrderStatus.shipped:
        return Colors.blue;
      case OrderStatus.delivered:
        return AppColors.success;
      case OrderStatus.cancelled:
        return AppColors.error;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.card,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.divider),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(FormatUtils.shortenId(order.id),
                  style: const TextStyle(
                      fontWeight: FontWeight.w700, fontSize: 14)),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: _statusColor(order.status).withOpacity(0.15),
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: _statusColor(order.status)),
                ),
                child: Text(
                  order.statusLabel,
                  style: TextStyle(
                    color: _statusColor(order.status),
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 4),
          Text(FormatUtils.dateTime(order.createdAt),
              style: const TextStyle(
                  color: AppColors.textSecondary, fontSize: 12)),
          const Divider(height: 20),
          // Items
          ...order.items.take(2).map(
                (item) => Padding(
                  padding: const EdgeInsets.only(bottom: 4),
                  child: Row(
                    children: [
                      Expanded(
                        child: Text(
                          '${item.name} x${item.quantity}',
                          style: const TextStyle(fontSize: 13),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                      Text(FormatUtils.currency(item.subtotal),
                          style: const TextStyle(fontSize: 13)),
                    ],
                  ),
                ),
              ),
          if (order.items.length > 2)
            Text(
              '+${order.items.length - 2} item lainnya',
              style: const TextStyle(
                  color: AppColors.textSecondary, fontSize: 12),
            ),
          const Divider(height: 20),
          // Total
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('Total Pembayaran',
                      style: TextStyle(
                          color: AppColors.textSecondary, fontSize: 12)),
                  Text(FormatUtils.currency(order.total),
                      style: const TextStyle(
                        color: AppColors.primary,
                        fontWeight: FontWeight.w700,
                        fontSize: 16,
                      )),
                ],
              ),
              Text(order.paymentMethod,
                  style: const TextStyle(
                      color: AppColors.textSecondary, fontSize: 12)),
            ],
          ),
        ],
      ),
    );
  }
}
