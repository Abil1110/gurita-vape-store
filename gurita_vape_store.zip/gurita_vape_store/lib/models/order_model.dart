import 'product_model.dart';

// ─── Cart Item ────────────────────────────────────────────────────────────────
class CartItemModel {
  final String productId;
  final String name;
  final double price;
  final String imageUrl;
  final String? selectedFlavor;
  int quantity;

  CartItemModel({
    required this.productId,
    required this.name,
    required this.price,
    required this.imageUrl,
    this.selectedFlavor,
    this.quantity = 1,
  });

  double get subtotal => price * quantity;

  factory CartItemModel.fromProduct(ProductModel p, {String? flavor}) {
    return CartItemModel(
      productId: p.id,
      name: p.name,
      price: p.price,
      imageUrl: p.imageUrl,
      selectedFlavor: flavor,
    );
  }

  Map<String, dynamic> toMap() => {
        'productId': productId,
        'name': name,
        'price': price,
        'imageUrl': imageUrl,
        'selectedFlavor': selectedFlavor,
        'quantity': quantity,
      };

  factory CartItemModel.fromMap(Map<String, dynamic> data) {
    return CartItemModel(
      productId: data['productId'],
      name: data['name'],
      price: (data['price'] as num).toDouble(),
      imageUrl: data['imageUrl'],
      selectedFlavor: data['selectedFlavor'],
      quantity: data['quantity'] ?? 1,
    );
  }
}

// ─── Order ────────────────────────────────────────────────────────────────────
enum OrderStatus { pending, processing, shipped, delivered, cancelled }

class OrderModel {
  final String id;
  final String userId;
  final List<CartItemModel> items;
  final double subtotal;
  final double shippingCost;
  final double total;
  final String shippingAddress;
  final String recipientName;
  final String recipientPhone;
  final String paymentMethod;
  final OrderStatus status;
  final String? notes;
  final DateTime createdAt;
  final DateTime? updatedAt;

  OrderModel({
    required this.id,
    required this.userId,
    required this.items,
    required this.subtotal,
    required this.shippingCost,
    required this.total,
    required this.shippingAddress,
    required this.recipientName,
    required this.recipientPhone,
    required this.paymentMethod,
    this.status = OrderStatus.pending,
    this.notes,
    required this.createdAt,
    this.updatedAt,
  });

  String get statusLabel {
    switch (status) {
      case OrderStatus.pending:
        return 'Menunggu Pembayaran';
      case OrderStatus.processing:
        return 'Diproses';
      case OrderStatus.shipped:
        return 'Dikirim';
      case OrderStatus.delivered:
        return 'Selesai';
      case OrderStatus.cancelled:
        return 'Dibatalkan';
    }
  }

  factory OrderModel.fromFirestore(Map<String, dynamic> data, String id) {
    return OrderModel(
      id: id,
      userId: data['userId'],
      items: (data['items'] as List<dynamic>)
          .map((i) => CartItemModel.fromMap(i))
          .toList(),
      subtotal: (data['subtotal'] as num).toDouble(),
      shippingCost: (data['shippingCost'] as num).toDouble(),
      total: (data['total'] as num).toDouble(),
      shippingAddress: data['shippingAddress'],
      recipientName: data['recipientName'],
      recipientPhone: data['recipientPhone'],
      paymentMethod: data['paymentMethod'],
      status: OrderStatus.values.firstWhere(
        (s) => s.name == (data['status'] ?? 'pending'),
        orElse: () => OrderStatus.pending,
      ),
      notes: data['notes'],
      createdAt: data['createdAt']?.toDate() ?? DateTime.now(),
      updatedAt: data['updatedAt']?.toDate(),
    );
  }

  Map<String, dynamic> toFirestore() => {
        'userId': userId,
        'items': items.map((i) => i.toMap()).toList(),
        'subtotal': subtotal,
        'shippingCost': shippingCost,
        'total': total,
        'shippingAddress': shippingAddress,
        'recipientName': recipientName,
        'recipientPhone': recipientPhone,
        'paymentMethod': paymentMethod,
        'status': status.name,
        'notes': notes,
        'createdAt': createdAt,
        'updatedAt': updatedAt,
      };
}
