class UserModel {
  final String uid;
  final String email;
  final String name;
  final String phone;
  final String photoUrl;
  final String role; // 'user' | 'admin'
  final List<String> wishlist;
  final List<AddressModel> addresses;
  final DateTime createdAt;

  UserModel({
    required this.uid,
    required this.email,
    this.name = '',
    this.phone = '',
    this.photoUrl = '',
    this.role = 'user',
    this.wishlist = const [],
    this.addresses = const [],
    required this.createdAt,
  });

  bool get isAdmin => role == 'admin';

  factory UserModel.fromFirestore(Map<String, dynamic> data, String uid) {
    return UserModel(
      uid: uid,
      email: data['email'] ?? '',
      name: data['name'] ?? '',
      phone: data['phone'] ?? '',
      photoUrl: data['photoUrl'] ?? '',
      role: data['role'] ?? 'user',
      wishlist: List<String>.from(data['wishlist'] ?? []),
      addresses: (data['addresses'] as List<dynamic>?)
              ?.map((a) => AddressModel.fromMap(a))
              .toList() ??
          [],
      createdAt: data['createdAt']?.toDate() ?? DateTime.now(),
    );
  }

  Map<String, dynamic> toFirestore() {
    return {
      'email': email,
      'name': name,
      'phone': phone,
      'photoUrl': photoUrl,
      'role': role,
      'wishlist': wishlist,
      'addresses': addresses.map((a) => a.toMap()).toList(),
      'createdAt': createdAt,
    };
  }

  UserModel copyWith({
    String? name,
    String? phone,
    String? photoUrl,
    String? role,
    List<String>? wishlist,
    List<AddressModel>? addresses,
  }) {
    return UserModel(
      uid: uid,
      email: email,
      name: name ?? this.name,
      phone: phone ?? this.phone,
      photoUrl: photoUrl ?? this.photoUrl,
      role: role ?? this.role,
      wishlist: wishlist ?? this.wishlist,
      addresses: addresses ?? this.addresses,
      createdAt: createdAt,
    );
  }
}

class AddressModel {
  final String id;
  final String label;
  final String recipient;
  final String phone;
  final String address;
  final String city;
  final String province;
  final String postalCode;
  final bool isDefault;

  AddressModel({
    required this.id,
    required this.label,
    required this.recipient,
    required this.phone,
    required this.address,
    required this.city,
    required this.province,
    required this.postalCode,
    this.isDefault = false,
  });

  factory AddressModel.fromMap(Map<String, dynamic> data) {
    return AddressModel(
      id: data['id'] ?? '',
      label: data['label'] ?? '',
      recipient: data['recipient'] ?? '',
      phone: data['phone'] ?? '',
      address: data['address'] ?? '',
      city: data['city'] ?? '',
      province: data['province'] ?? '',
      postalCode: data['postalCode'] ?? '',
      isDefault: data['isDefault'] ?? false,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'label': label,
      'recipient': recipient,
      'phone': phone,
      'address': address,
      'city': city,
      'province': province,
      'postalCode': postalCode,
      'isDefault': isDefault,
    };
  }
}
