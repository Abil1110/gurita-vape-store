class ProductModel {
  final String id;
  final String name;
  final String description;
  final double price;
  final double? originalPrice;
  final String imageUrl;
  final String category;
  final String brand;
  final double rating;
  final int reviewCount;
  final int stock;
  final List<String> flavors;
  final Map<String, String> specs;
  final bool isNew;
  final bool isFeatured;
  final DateTime createdAt;

  ProductModel({
    required this.id,
    required this.name,
    required this.description,
    required this.price,
    this.originalPrice,
    required this.imageUrl,
    required this.category,
    required this.brand,
    this.rating = 0.0,
    this.reviewCount = 0,
    this.stock = 0,
    this.flavors = const [],
    this.specs = const {},
    this.isNew = false,
    this.isFeatured = false,
    required this.createdAt,
  });

  bool get isDiscount => originalPrice != null && originalPrice! > price;
  int get discountPercent => isDiscount
      ? (((originalPrice! - price) / originalPrice!) * 100).round()
      : 0;
  bool get isInStock => stock > 0;

  factory ProductModel.fromFirestore(Map<String, dynamic> data, String id) {
    return ProductModel(
      id: id,
      name: data['name'] ?? '',
      description: data['description'] ?? '',
      price: (data['price'] ?? 0).toDouble(),
      originalPrice: data['originalPrice'] != null
          ? (data['originalPrice']).toDouble()
          : null,
      imageUrl: data['imageUrl'] ?? '',
      category: data['category'] ?? '',
      brand: data['brand'] ?? '',
      rating: (data['rating'] ?? 0).toDouble(),
      reviewCount: data['reviewCount'] ?? 0,
      stock: data['stock'] ?? 0,
      flavors: List<String>.from(data['flavors'] ?? []),
      specs: Map<String, String>.from(data['specs'] ?? {}),
      isNew: data['isNew'] ?? false,
      isFeatured: data['isFeatured'] ?? false,
      createdAt: data['createdAt']?.toDate() ?? DateTime.now(),
    );
  }

  Map<String, dynamic> toFirestore() {
    return {
      'name': name,
      'description': description,
      'price': price,
      'originalPrice': originalPrice,
      'imageUrl': imageUrl,
      'category': category,
      'brand': brand,
      'rating': rating,
      'reviewCount': reviewCount,
      'stock': stock,
      'flavors': flavors,
      'specs': specs,
      'isNew': isNew,
      'isFeatured': isFeatured,
      'createdAt': createdAt,
    };
  }

  ProductModel copyWith({
    String? id,
    String? name,
    String? description,
    double? price,
    double? originalPrice,
    String? imageUrl,
    String? category,
    String? brand,
    double? rating,
    int? reviewCount,
    int? stock,
    List<String>? flavors,
    Map<String, String>? specs,
    bool? isNew,
    bool? isFeatured,
    DateTime? createdAt,
  }) {
    return ProductModel(
      id: id ?? this.id,
      name: name ?? this.name,
      description: description ?? this.description,
      price: price ?? this.price,
      originalPrice: originalPrice ?? this.originalPrice,
      imageUrl: imageUrl ?? this.imageUrl,
      category: category ?? this.category,
      brand: brand ?? this.brand,
      rating: rating ?? this.rating,
      reviewCount: reviewCount ?? this.reviewCount,
      stock: stock ?? this.stock,
      flavors: flavors ?? this.flavors,
      specs: specs ?? this.specs,
      isNew: isNew ?? this.isNew,
      isFeatured: isFeatured ?? this.isFeatured,
      createdAt: createdAt ?? this.createdAt,
    );
  }
}

// Product categories
class ProductCategory {
  static const String pod = 'Pod';
  static const String mod = 'Mod';
  static const String liquid = 'Liquid';
  static const String coil = 'Coil';
  static const String accessories = 'Accessories';

  static const List<String> all = [pod, mod, liquid, coil, accessories];
}
